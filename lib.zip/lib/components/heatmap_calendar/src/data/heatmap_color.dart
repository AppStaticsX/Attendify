import 'package:flutter/material.dart';

class HeatMapColor {
  /// Default background color of every block.
  static const Color defaultColor = Color(0xFFF8F9FA);
}
