enum ColorMode {
  opacity,
  color,
}
